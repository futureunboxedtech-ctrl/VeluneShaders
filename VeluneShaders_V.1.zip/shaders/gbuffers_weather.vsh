#version 330 compatibility
#define PASS_WEATHER
#include "/lib/lit_vert.glsl"
