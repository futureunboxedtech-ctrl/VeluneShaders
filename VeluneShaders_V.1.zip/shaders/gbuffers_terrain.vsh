#version 330 compatibility
#define PASS_TERRAIN
#define USE_BLOCK_ID
#include "/lib/lit_vert.glsl"
