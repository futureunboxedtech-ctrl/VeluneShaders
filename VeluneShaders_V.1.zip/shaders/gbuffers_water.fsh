#version 330 compatibility
/* DRAWBUFFERS:012 */
#define PASS_WATER
#define USE_BLOCK_ID
#include "/lib/lit_frag.glsl"
