#version 330 compatibility
#define PASS_CLOUDS
#include "/lib/lit_vert.glsl"
