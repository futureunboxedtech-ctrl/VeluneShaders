#version 330 compatibility
/* DRAWBUFFERS:04 */
#define PASS_TERRAIN
#define USE_BLOCK_ID
#include "/lib/lit_frag.glsl"
