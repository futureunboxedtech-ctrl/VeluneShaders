#version 330 compatibility
#define PASS_PARTICLE
#include "/lib/lit_frag.glsl"
