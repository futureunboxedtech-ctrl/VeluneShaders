#version 330 compatibility
in vec4 glcolor;
void main() { gl_FragData[0] = vec4(pow(glcolor.rgb, vec3(2.2)), glcolor.a); }
