#version 330 compatibility
#include "/lib/emissive_frag.glsl"
