#version 330 compatibility
#define DIM_END
/* DRAWBUFFERS:04 */
#define PASS_TERRAIN
#define USE_BLOCK_ID
#include "/lib/lit_frag.glsl"
