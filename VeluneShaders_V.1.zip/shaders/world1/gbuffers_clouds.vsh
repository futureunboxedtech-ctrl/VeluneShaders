#version 330 compatibility
#define DIM_END
#define PASS_CLOUDS
#include "/lib/lit_vert.glsl"
