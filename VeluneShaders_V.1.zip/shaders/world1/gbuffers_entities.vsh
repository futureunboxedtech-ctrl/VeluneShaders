#version 330 compatibility
#define DIM_END
#define PASS_ENTITY
#include "/lib/lit_vert.glsl"
