#version 330 compatibility
#define DIM_END
void main() { gl_FragData[0] = vec4(0.0); }
