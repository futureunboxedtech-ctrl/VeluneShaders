#version 330 compatibility
#define DIM_END
#include "/lib/emissive_frag.glsl"
