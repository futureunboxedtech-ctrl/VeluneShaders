#version 330 compatibility
#define DIM_END
void main() { discard; }
