#version 330 compatibility
#define DIM_END
#define PASS_WEATHER
#include "/lib/lit_frag.glsl"
