#version 330 compatibility
#define DIM_END
#define USE_BLOCK_ID
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/wind.glsl"
#include "/lib/shadow.glsl"

in vec4 mc_Entity;
in vec2 mc_midTexCoord;
out vec2 texcoord;
out vec4 glcolor;
flat out float blockId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    glcolor = gl_Color;
    blockId = mc_Entity.x;
    vec4 vp = gl_ModelViewMatrix * gl_Vertex;
#ifdef WAVING_PLANTS
    if (blockId > 10001.5) {
        vec3 feet = (shadowModelViewInverse * vp).xyz;
        float top = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
        feet += windOffset(feet + cameraPosition, blockId, top);
        vp = shadowModelView * vec4(feet, 1.0);
    }
#endif
    gl_Position = gl_ProjectionMatrix * vp;
    gl_Position.xy /= shadowDistortFactor(gl_Position.xy);
}
