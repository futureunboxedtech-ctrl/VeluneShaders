#version 330 compatibility
#define DIM_END
in vec4 glcolor;
void main() { gl_FragData[0] = vec4(pow(glcolor.rgb, vec3(2.2)), glcolor.a); }
