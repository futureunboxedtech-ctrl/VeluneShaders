#version 330 compatibility
#define DIM_END
void main() { gl_Position = ftransform(); }
