#version 330 compatibility
#define DIM_END
#define PASS_HAND
#include "/lib/lit_vert.glsl"
