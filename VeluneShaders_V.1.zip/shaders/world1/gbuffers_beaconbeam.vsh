#version 330 compatibility
#define DIM_END
#include "/lib/simple_vert.glsl"
