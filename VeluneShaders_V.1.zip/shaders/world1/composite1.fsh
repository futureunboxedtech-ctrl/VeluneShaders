#version 330 compatibility
#define DIM_END
/* DRAWBUFFERS:3 */
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
in vec2 uv;
// bright-pass + horizontal blur
void main() {
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 sum = vec3(0.0);
    float tot = 0.0;
    for (int i = -7; i <= 7; i++) {
        float w = exp(-float(i * i) / 24.5);
        vec3 c = min(texture(colortex0, uv + vec2(float(i) * 2.0 * px.x, 0.0)).rgb, vec3(30.0));
        float l = luma(c);
        c *= max(l - 1.2, 0.0) / max(l, 1e-4);
        sum += c * w;
        tot += w;
    }
    gl_FragData[0] = vec4(sum / tot, 1.0);
}
