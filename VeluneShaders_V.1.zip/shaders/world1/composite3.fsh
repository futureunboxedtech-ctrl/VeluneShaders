#version 330 compatibility
#define DIM_END
/* DRAWBUFFERS:0 */
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/atmos.glsl"
in vec2 uv;

vec3 toView(vec2 p, float d) {
    vec4 v = gbufferProjectionInverse * vec4(vec3(p, d) * 2.0 - 1.0, 1.0);
    return v.xyz / v.w;
}

vec3 aces(vec3 x) {
    x *= 0.6;
    return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0);
}

void main() {
    vec3 col = texture(colortex0, uv).rgb;
    float d0 = texture(depthtex0, uv).r;
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    float asp = viewWidth / viewHeight;

#ifdef MOTION_BLUR
    if (d0 > 0.56 && d0 < 1.0) {
        vec3 vp = toView(uv, d0);
        vec3 wp = (gbufferModelViewInverse * vec4(vp, 1.0)).xyz + cameraPosition;
        vec4 pv = gbufferPreviousModelView * vec4(wp - previousCameraPosition, 1.0);
        vec4 pc = gbufferPreviousProjection * pv;
        vec2 prevUV = pc.xy / pc.w * 0.5 + 0.5;
        vec2 vel = (uv - prevUV) * 0.5;
        float vl = length(vel);
        if (vl > 0.03) vel *= 0.03 / vl;
        vec3 acc = vec3(0.0);
        for (int i = 0; i < 8; i++) {
            float k = (float(i) + 0.5) / 8.0 - 0.5;
            acc += texture(colortex0, clamp(uv + vel * k, vec2(0.001), vec2(0.999))).rgb;
        }
        col = acc * 0.125;
    }
#endif

#ifdef DOF
    if (d0 > 0.56) {
        float dist = length(toView(uv, d0));
        float focus = length(toView(vec2(0.5), centerDepthSmooth));
        float coc = clamp(abs(dist - focus) / max(dist, 1.0) * 0.012 * DOF_STRENGTH, 0.0, 0.012);
        if (coc > 0.0006) {
            vec3 acc = col;
            float tot = 1.0;
            for (int i = 0; i < 12; i++) {
                float a = float(i) * 2.39996;
                float r = sqrt((float(i) + 0.5) / 12.0) * coc;
                vec2 suv = clamp(uv + vec2(cos(a) / asp, sin(a)) * r, vec2(0.001), vec2(0.999));
                acc += texture(colortex0, suv).rgb;
                tot += 1.0;
            }
            col = mix(col, acc / tot, clamp(coc / 0.003, 0.0, 1.0));
        }
    }
#endif

    float expo = EXPOSURE;
    float tw = 0.0, night = 0.0;
#ifdef DIM_OVERWORLD
    vec3 sunDirW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    tw = twilightAmount(sunDirW.y);
    night = 1.0 - dayAmount(sunDirW.y);
    expo *= 1.0 + 0.50 * night * (1.0 - 0.5 * rainStrength);

    #ifdef LENS_FLARE
    if (sunPosition.z < 0.0 && sunDirW.y > -0.05) {
        vec4 sc = gbufferProjection * vec4(sunPosition, 1.0);
        vec2 sUV = sc.xy / sc.w * 0.5 + 0.5;
        float vis = 0.0;
        for (int i = 0; i < 5; i++) {
            vec2 o = (i == 0) ? vec2(0.0) : vec2(cos(float(i) * 1.5708), sin(float(i) * 1.5708)) * 0.012;
            vec2 su = sUV + o;
            vis += (su.x > 0.0 && su.x < 1.0 && su.y > 0.0 && su.y < 1.0) ? step(1.0, texture(depthtex0, su).r) : 0.0;
        }
        vis *= 0.2;
        float edgeFade = 1.0 - smoothstep(0.55, 1.1, length((sUV - 0.5) * vec2(asp, 1.0)));
        float f = vis * edgeFade * smoothstep(-0.05, 0.15, sunDirW.y) * (1.0 - rainStrength);
        if (f > 0.001) {
            vec2 dv = (uv - sUV) * vec2(asp, 1.0);
            float r = length(dv);
            vec3 sc0 = sunTint(sunDirW.y);
            vec3 fl = sc0 * (0.05 / (r + 0.05)) * 0.35;
            for (int g = 0; g < 3; g++) {
                float kk = 0.55 + 0.7 * float(g);
                vec2 gc = vec2(0.5) + (vec2(0.5) - sUV) * kk;
                float gd = length((uv - gc) * vec2(asp, 1.0));
                float rad = 0.05 + 0.03 * float(g);
                vec3 tint = (g == 0) ? vec3(1.0, 0.6, 0.3) : (g == 1 ? vec3(0.4, 0.8, 1.0) : vec3(0.8, 0.4, 1.0));
                fl += tint * (exp(-sq((gd - rad) * 40.0)) * 0.12 + (1.0 - smoothstep(0.0, rad, gd)) * 0.04);
            }
            col += fl * f * 0.8;
        }
    }
    #endif
#endif

#ifdef BLOOM
    float bs = BLOOM_STRENGTH;
    #if defined(DIM_NETHER)
    bs *= 1.5;
    #elif defined(DIM_END)
    bs *= 1.15;
    #else
    bs *= 1.0 + 0.8 * night;
    #endif
    col += texture(colortex3, uv).rgb * bs * (1.0 + 0.4 * tw);
#endif
    col *= expo;
    col = aces(col);
    col = pow(col, vec3(1.0 / 2.2));

    float sat = SATURATION;
#ifdef DIM_OVERWORLD
    sat *= 1.0 + 0.30 * night;
#endif
    col = mix(vec3(luma(col)), col, sat);
    col = mix(col, col * col * (3.0 - 2.0 * col), 0.25);
    col *= mix(vec3(0.98, 1.0, 1.03), vec3(1.03, 1.0, 0.97), luma(col));

#if defined(DIM_NETHER)
    col *= vec3(1.04, 0.99, 0.95);
    col = mix(col, col * col * (3.0 - 2.0 * col), 0.2);
#elif defined(DIM_END)
    col = mix(vec3(luma(col)), col, 0.92);
    col *= vec3(1.04, 1.0, 0.95);
    col = mix(col, col * col * (3.0 - 2.0 * col), 0.25);
#else
    col *= mix(vec3(1.0), vec3(1.10, 0.95, 0.86), tw * 0.55 * SUNSET_INTENSITY);
    col += vec3(0.018, 0.004, 0.030) * tw * (1.0 - luma(col));
    col = mix(col, col * vec3(0.80, 0.96, 1.25), night * 0.75);
    col += vec3(0.010, 0.016, 0.040) * night * (1.0 - luma(col));
    col = mix(col, col * col * (3.0 - 2.0 * col), night * 0.15);
#endif

#ifdef VIGNETTE
    vec2 q = uv - 0.5;
    col *= 1.0 - dot(q, q) * 0.55;
#endif
    col += (ign(gl_FragCoord.xy) - 0.5) / 255.0;
    gl_FragData[0] = vec4(clamp(col, 0.0, 1.0), 1.0);
}
