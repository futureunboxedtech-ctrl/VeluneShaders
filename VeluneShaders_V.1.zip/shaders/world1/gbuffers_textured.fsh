#version 330 compatibility
#define DIM_END
#define PASS_PARTICLE
#include "/lib/lit_frag.glsl"
