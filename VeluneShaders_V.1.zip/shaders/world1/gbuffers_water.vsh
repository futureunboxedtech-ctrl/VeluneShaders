#version 330 compatibility
#define DIM_END
#define PASS_WATER
#define USE_BLOCK_ID
#include "/lib/lit_vert.glsl"
