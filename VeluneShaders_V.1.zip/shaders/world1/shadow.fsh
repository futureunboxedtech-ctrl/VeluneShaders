#version 330 compatibility
#define DIM_END
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
in vec2 texcoord;
in vec4 glcolor;
flat in float blockId;
void main() {
    vec4 c = texture(gtexture, texcoord);
    c.rgb *= glcolor.rgb;
    if (c.a < 0.1) discard;
    if (abs(blockId - 10001.0) < 0.5) c = vec4(0.30, 0.65, 0.85, 0.55);
    gl_FragData[0] = c;
}
