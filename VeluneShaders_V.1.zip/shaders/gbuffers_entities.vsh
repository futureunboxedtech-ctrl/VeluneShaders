#version 330 compatibility
#define PASS_ENTITY
#include "/lib/lit_vert.glsl"
