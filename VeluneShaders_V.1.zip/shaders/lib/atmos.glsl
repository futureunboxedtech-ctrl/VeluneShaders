// requires common.glsl + uniforms.glsl
#ifndef ATMOS_GLSL
#define ATMOS_GLSL

float dayAmount(float h) { return smoothstep(-0.14, 0.16, h); }
float twilightAmount(float h) { return smoothstep(-0.28, -0.02, h) * (1.0 - smoothstep(0.02, 0.40, h)); }
vec3 sunTint(float h) { return mix(vec3(1.0, 0.34, 0.07), vec3(1.0, 0.92, 0.80), smoothstep(0.0, 0.5, h)); }

// colour of the active shadow-casting light (sun by day, moon by night)
vec3 getLightColor(vec3 sunDirW) {
    float h = sunDirW.y;
    vec3 sunC  = sunTint(h) * SUN_INTENSITY * smoothstep(0.0, 0.12, h);
    vec3 moonC = vec3(0.50, 0.62, 1.0) * 0.50 * smoothstep(0.0, 0.20, -h);
    vec3 c = (h > 0.0) ? sunC : moonC;
    return c * (1.0 - 0.85 * rainStrength);
}

vec3 getSkyAmbient(vec3 sunDirW) {
    float h = sunDirW.y;
    float d = dayAmount(h);
    float tw = twilightAmount(h);
    vec3 dayA = vec3(0.52, 0.69, 1.05);
    vec3 nightA = vec3(0.075, 0.095, 0.185);
    vec3 a = mix(nightA, dayA, d);
    a = mix(a, mix(a, vec3(0.62, 0.38, 0.64), 0.55), tw);
    a = mix(a, vec3(luma(a)) * vec3(0.95, 1.0, 1.05), rainStrength * 0.7) * (1.0 - 0.35 * rainStrength);
    return a;
}

// ---------------------------------------------------------------- sky
vec3 getSky(vec3 dir, vec3 sunDirW) {
    float h = sunDirW.y;
    float day = dayAmount(h);
    float tw = twilightAmount(h);
    float hh = clamp(dir.y, 0.0, 1.0);

    // day / night base
    vec3 zen = mix(vec3(0.010, 0.020, 0.075), vec3(0.17, 0.44, 1.05), day);
    vec3 hor = mix(vec3(0.040, 0.070, 0.160), vec3(0.72, 0.92, 1.25), day);
    vec3 sky = mix(hor, zen, pow(hh, 0.6));

    // sunset / sunrise palette: indigo zenith, magenta mid, molten-orange horizon
    vec2 sa = normalize(sunDirW.xz + vec2(1e-5));
    vec2 da = normalize(dir.xz + vec2(1e-5));
    float az = dot(da, sa);
    float sunSide  = sq(max(az, 0.0));
    float antiSide = sq(max(-az, 0.0));
    float band = pow(1.0 - hh, 2.5);
    vec3 twZen = vec3(0.07, 0.09, 0.34);
    vec3 twMid = mix(vec3(0.55, 0.20, 0.48), vec3(0.95, 0.32, 0.38), sunSide);
    vec3 twHor = mix(vec3(0.75, 0.40, 0.45), vec3(1.15, 0.50, 0.14), sunSide);
    vec3 tws = mix(twHor, twMid, smoothstep(0.0, 0.30, hh));
    tws = mix(tws, twZen, smoothstep(0.20, 0.85, hh));
    float cs = max(dot(dir, sunDirW), 0.0);
    tws += vec3(1.0, 0.55, 0.15) * (pow(cs, 6.0) * 0.8 + pow(cs, 40.0) * 1.2);
    tws += vec3(0.55, 0.30, 0.55) * antiSide * band * 0.5;           // belt of Venus
    tws = mix(vec3(luma(tws)), tws, SUNSET_INTENSITY);
    sky = mix(sky, tws, clamp(tw * 1.15, 0.0, 1.0));

    // daytime Mie glow around the sun, moon halo at night
    sky += sunTint(h) * (pow(cs, 10.0) * 0.15 + pow(cs, 200.0) * 0.8) * smoothstep(-0.10, 0.10, h) * (1.0 - tw);
    float cm = max(dot(dir, -sunDirW), 0.0);
    float moonGlow = pow(cm, 30.0) * 0.10 + pow(cm, 300.0) * 0.7 + pow(cm, 3000.0) * 0.8;
    float ring = exp(-sq((acos(clamp(cm, -1.0, 1.0)) - 0.38) * 14.0)) * 0.035;   // faint 22-degree halo
    sky += vec3(0.38, 0.50, 0.90) * (moonGlow + ring) * (1.0 - day);

    // night: violet-teal horizon glow
    sky += vec3(0.05, 0.05, 0.14) * pow(1.0 - hh, 3.0) * (1.0 - day) * (1.0 - tw);
    sky *= mix(1.0, 0.5, 1.0 - smoothstep(-0.3, 0.0, dir.y));
    sky = mix(sky, vec3(luma(sky)) * vec3(0.78, 0.82, 0.90), rainStrength * 0.8);
    sky *= 1.0 - 0.3 * rainStrength;
    return sky;
}

// ---------------------------------------------------------------- stars / aurora
vec3 starLayer(vec3 dir, float scale, float thresh, float rad, float seed, float t, float twinkle) {
    vec3 p = dir * scale + seed;
    vec3 id = floor(p);
    float rnd = hash13(id);
    if (rnd <= thresh) return vec3(0.0);
    vec3 f = fract(p) - 0.5;
    vec3 off = (vec3(hash13(id + 1.7), hash13(id + 3.1), hash13(id + 5.3)) - 0.5) * 0.5;
    float d = length(f - off);
    float core = 1.0 - smoothstep(0.0, rad * 0.55, d);
    float halo = exp(-d * d / (rad * rad * 1.2)) * 0.4;
    float h9 = hash13(id + 9.9);
    float b = 0.5 + 3.5 * h9 * h9 * h9;                       // a few very bright stars
    b *= 1.0 - twinkle + twinkle * (0.5 + 0.5 * sin(t * (2.0 + 4.0 * hash13(id + 2.2)) + rnd * 40.0));
    float k = hash13(id + 7.7);                                // stellar colour classes
    vec3 tint = k < 0.30 ? vec3(0.65, 0.78, 1.00)
              : k < 0.70 ? vec3(1.00, 0.97, 0.92)
              : k < 0.90 ? vec3(1.00, 0.85, 0.60)
                         : vec3(1.00, 0.60, 0.45);
    return tint * (core + halo) * b;
}

// occasional shooting stars
vec3 shootingStars(vec3 dir, float t) {
    vec3 res = vec3(0.0);
    if (dir.y < 0.08) return res;
    for (int k = 0; k < 2; k++) {
        float period = 7.0 + 3.0 * float(k);
        float tt = t / period + float(k) * 0.37;
        float seed = floor(tt) + float(k) * 13.0;
        float ph = fract(tt);
        float life = 0.12;
        if (hash12(vec2(seed, 1.3)) > 0.55 && ph < life) {
            float u = ph / life;
            vec3 p0 = normalize(vec3(hash12(vec2(seed, 2.1)) - 0.5, 0.35 + 0.6 * hash12(vec2(seed, 3.7)), hash12(vec2(seed, 4.9)) - 0.5));
            vec3 v = normalize(cross(p0, vec3(hash12(vec2(seed, 6.1)) - 0.5, 0.2, hash12(vec2(seed, 7.3)) - 0.5)));
            vec3 head = normalize(p0 + v * (u * 0.5));
            vec3 tail = normalize(p0 + v * (u * 0.5 - 0.14));
            if (dot(dir, head) > 0.97) {
                vec3 ab = head - tail;
                float s = clamp(dot(dir - tail, ab) / dot(ab, ab), 0.0, 1.0);
                float d = length(dir - normalize(tail + ab * s));
                float streak = 1.0 - smoothstep(0.0, 0.0035, d);
                res += vec3(0.80, 0.92, 1.0) * streak * s * s * sin(u * PI) * 7.0;
            }
        }
    }
    return res;
}

vec3 getAurora(vec3 dir, float t) {
    if (dir.y < 0.04) return vec3(0.0);
    vec3 col = vec3(0.0);
    for (int i = 0; i < 8; i++) {
        float fi = float(i);
        float hgt = (0.9 + fi * 0.09) / (dir.y + 0.12);
        vec2 p = dir.xz * hgt;
        float f = vnoise(vec2(p.x * 0.55 + t * 0.05, p.y * 0.22 + fi * 3.1));
        float ribbon = pow(max(1.0 - abs(f - 0.5) * 2.4, 0.0), 5.0);
        float flick = 0.6 + 0.4 * vnoise(vec2(p.x * 2.0 - t * 0.3, fi));
        vec3 c = mix(vec3(0.15, 1.0, 0.55), vec3(0.65, 0.25, 1.0), fi / 7.0);
        col += c * ribbon * flick * exp(-fi * 0.22);
    }
    return col * 0.40 * smoothstep(0.04, 0.35, dir.y);
}

// sun disk (optional), procedural moon with phases, stars, milky way.
// starBoost > 1 enlarges/brightens stars (used for water reflections)
vec3 getCelestials(vec3 dir, vec3 sunDirW, bool withSun, float starBoost) {
    float h = sunDirW.y;
    float day = dayAmount(h);
    float clear = 1.0 - rainStrength;
    vec3 res = vec3(0.0);

    if (withSun) {
        float cs = dot(dir, sunDirW);
        float sun = smoothstep(0.9978, 0.9986, cs);
        res += sunTint(h) * 40.0 * sun * smoothstep(-0.10, 0.02, h) * clear;
    }

    // moon
    vec3 md = -sunDirW;
    float cm = dot(dir, md);
    if (cm > 0.995) {
        vec3 r = (abs(md.y) > 0.99) ? vec3(1.0, 0.0, 0.0) : normalize(cross(md, vec3(0.0, 1.0, 0.0)));
        vec3 u = cross(r, md);
        vec2 q = vec2(dot(dir, r), dot(dir, u)) / 0.065;
        float r2 = dot(q, q);
        if (r2 < 1.0) {
            vec3 n = vec3(q, sqrt(1.0 - r2));
            float phi = float(moonPhase) * PI * 0.25;
            vec3 L = vec3(sin(phi), 0.0, cos(phi));
            float lit = smoothstep(-0.04, 0.10, dot(n, L));
            float t = vnoise(q * 3.0 + 7.0) * 0.6 + vnoise(q * 9.0) * 0.3;
            float alb = 0.55 + 0.45 * smoothstep(0.25, 0.65, t);
            float edge = 1.0 - smoothstep(0.85, 1.0, r2);
            res += vec3(0.88, 0.92, 1.0) * alb * (lit + 0.02) * 6.0 * edge * (1.0 - 0.7 * day) * clear;
        }
    }

    // stars, milky way, shooting stars
    if (dir.y > 0.0 && day < 0.98) {
        float vis = (1.0 - day) * clear * smoothstep(0.0, 0.1, dir.y);
        float rb = min(starBoost, 1.5);
        vec3 st = starLayer(dir,  90.0, 0.986, 0.28 * rb,  0.0, frameTimeCounter, 0.45) * 1.6
                + starLayer(dir, 170.0, 0.986, 0.24 * rb, 17.0, frameTimeCounter, 0.45)
                + starLayer(dir, 340.0, 0.984, 0.20 * rb, 41.0, frameTimeCounter, 0.30) * 0.6;
        res += st * 2.0 * starBoost * vis;

        vec3 gN = normalize(vec3(0.35, 0.75, -0.45));
        float gd = dot(dir, gN);
        float gb = exp(-sq(gd * 4.0));
        float gwide = exp(-sq(gd * 1.6)) * 0.04;
        if (gb > 0.02 || gwide > 0.005) {
            float cn = fbm3(dir * 4.0);
            float cn2 = fbm3(dir * 7.0 + 3.0);
            float lane = smoothstep(0.45, 0.70, fbm3(dir * 9.0 + 5.0));
            vec3 gcol = mix(vec3(0.30, 0.40, 0.85), vec3(0.95, 0.55, 0.60), cn2);
            gcol = mix(gcol, vec3(1.0, 0.80, 0.50), smoothstep(0.6, 1.0, gb) * 0.5);    // warm galactic core
            res += (gcol * gb * (0.35 + 0.9 * cn) * (1.0 - 0.55 * lane * gb) * 0.22
                    + vec3(0.25, 0.30, 0.60) * gwide) * vis;
        }
        res += shootingStars(dir, frameTimeCounter) * vis * starBoost;
    }
    return res;
}

// ---------------------------------------------------------------- clouds
// procedural drifting cloud layer, lit by the sun/moon, glowing at sunset
vec4 getClouds(vec3 dir, vec3 sunDirW, vec3 lightC, vec3 skyA) {
    if (dir.y < 0.015) return vec4(0.0);
    float t = frameTimeCounter;
    vec2 p = dir.xz / (dir.y + 0.12) * 1.6 + vec2(t * 0.015, t * 0.006);
    float th = 0.78 - CLOUD_COVERAGE * 0.5 - rainStrength * 0.15;
    float n = fbm2(p * 0.5);
    float dens = smoothstep(th, th + 0.22, n);
    if (dens < 0.003) return vec4(0.0);
    vec2 sd = normalize(sunDirW.xz + vec2(1e-4)) * 0.22;
    float n2 = fbm2(p * 0.5 + sd);
    float lightT = clamp(0.75 - (n2 - n) * 3.5, 0.0, 1.0);
    lightT *= mix(1.0, 0.55, smoothstep(th + 0.1, th + 0.5, n));
    float tw = twilightAmount(sunDirW.y);
    float edge = dens * (1.0 - dens) * 4.0;
    vec3 c = skyA * 0.9 + lightC * 0.45 * lightT;
    c += lightC * 0.35 * edge * lightT;                                   // silver lining
    vec3 glow = getSky(normalize(vec3(dir.x, 0.05, dir.z)), sunDirW) * 1.1 + lightC * 0.5 * lightT;
    c = mix(c, glow, 0.6 * tw);                                           // sunset-lit clouds
    float a = dens * smoothstep(0.015, 0.20, dir.y) * 0.95;
    return vec4(c, a);
}

// ---------------------------------------------------------------- fireflies (only near firefly bushes)
// is a firefly bush (marked in colortex4.a by the terrain pass) within ~3.5 blocks of this point?
bool bushNear(vec3 rc, float tp) {
    vec4 vp = gbufferModelView * vec4(rc, 1.0);
    if (vp.z > -0.1) return false;
    vec4 cp = gbufferProjection * vp;
    vec2 cuv = cp.xy / cp.w * 0.5 + 0.5;
    float R = clamp(3.5 / tp * gbufferProjection[1][1] * 0.5, 0.004, 0.3);
    float asp = viewHeight / viewWidth;
    for (int i = 0; i < 9; i++) {
        vec2 suv = cuv;
        if (i > 0) {
            float ang = float(i - 1) * 0.7854;
            float rr = ((i & 1) == 1) ? 0.55 * R : R;
            suv += vec2(cos(ang) * asp, sin(ang)) * rr;
        }
        if (suv.x < 0.0 || suv.y < 0.0 || suv.x > 1.0 || suv.y > 1.0) continue;
        if (texture(colortex4, suv).a > 0.5) {
            float sd = texture(depthtex1, suv).r;
            vec4 v = gbufferProjectionInverse * vec4(vec3(suv, sd) * 2.0 - 1.0, 1.0);
            if (distance(v.xyz / v.w, vp.xyz) < 3.5) return true;
        }
    }
    return false;
}

vec3 fireflies(vec3 dir, float maxDist, vec3 color, float t) {
    vec3 acc = vec3(0.0);
    for (int i = 0; i < 8; i++) {
        float d = 2.0 + float(i) * 3.0;
        if (d > maxDist) break;
        vec3 g = dir * d + cameraPosition;
        vec3 cell = floor(g / 3.0);
        float r1 = hash13(cell);
        if (r1 > 0.75) continue;
        float r2 = hash13(cell + 7.1);
        float r3 = hash13(cell + 13.7);
        float r4 = hash13(cell + 3.3);
        vec3 cG = (cell + 0.15 + 0.7 * vec3(r2, r3, r4)) * 3.0;
        cG += vec3(sin(t * 0.7 + r2 * 20.0), sin(t * 0.9 + r3 * 20.0), sin(t * 0.6 + r1 * 20.0)) * 0.6;
        vec3 rc = cG - cameraPosition;
        if (abs(rc.y + 1.0) > 4.0) continue;
        float tp = dot(rc, dir);
        if (tp < 0.5 || tp > maxDist) continue;
        float ang = length(rc - dir * tp) / tp;
        float glow = exp(-ang * ang / 0.00012);
        if (glow < 0.02) continue;
        if (!bushNear(rc, tp)) continue;                       // only around firefly bushes
        float blink = pow(0.5 + 0.5 * sin(t * (0.8 + 1.5 * r2) + r3 * 50.0), 3.0) * 1.5;
        acc += color * glow * blink;
    }
    return acc;
}

// ---------------------------------------------------------------- the End
// Units are Schwarzschild radii (rs = 1). Photon sphere 1.5, shadow radius 2.598, ISCO 3.
#define BH_RS 1.0
#define BH_D float(BH_DIST)
#define BH_RIN 3.0
#define BH_ROUT 10.5

// The black hole is the End's "sun": it sits where Iris' shadow light is, so the shadow map,
// the lighting and the object in the sky all agree. (BH_LOCK_LIGHT off = fixed world direction.)
vec3 bhDir() {
#ifdef BH_LOCK_LIGHT
    vec3 s = shadowLightPosition;
    if (dot(s, s) > 1.0) return normalize(mat3(gbufferModelViewInverse) * s);
#endif
    return normalize(vec3(BH_WORLD_X, BH_WORLD_Y, BH_WORLD_Z) + vec3(0.0, 0.0, 1e-5));
}
#define BH_DIR bhDir()
vec3 endLightColor() { return vec3(1.0, 0.86, 0.68) * 3.0; }

// stable world-space tangent frame around the black hole direction (never camera-derived)
void bhFrame(vec3 bh, out vec3 right, out vec3 up) {
    right = cross(vec3(0.0, 1.0, 0.0), bh);
    if (dot(right, right) < 1e-5) right = cross(vec3(1.0, 0.0, 0.0), bh);
    right = normalize(right);
    up = normalize(cross(bh, right));
}

// Ringed gas giant beside the black hole, lit from the black hole's side: banded cloud tops,
// limb haze, a lit/dark terminator, ring shadow on the planet and planet shadow on the rings.
vec3 planetLayer(vec3 dir, vec3 col, vec3 bh) {
    vec3 right, up;
    bhFrame(bh, right, up);
    const float Rp = 7.6;
    const float Dp = 58.0;
    vec3 Pd = normalize(bh * cos(0.70) + right * sin(0.70) - up * 0.10);
    vec3 C = Pd * Dp;
    vec3 w = normalize(up * cos(0.40) + right * sin(0.40));
    w = normalize(w - Pd * dot(w, Pd));
    vec3 np = normalize(-Pd * 0.342 + w * 0.940);        // ring/rotation axis, ~20 degrees above ring plane
    vec3 Lp = normalize(bh * BH_D - C);                  // from the planet toward the black hole
    float R1 = 1.24 * Rp, R2 = 2.25 * Rp;

    float tp = 1e9;
    bool pHit = false;
    vec3 pcol = vec3(0.0);
    float bq = dot(dir, C);
    float disc = bq * bq - (dot(C, C) - Rp * Rp);
    if (disc > 0.0) {
        tp = bq - sqrt(disc);
        if (tp > 0.0) {
            pHit = true;
            vec3 sp = dir * tp;
            vec3 n = normalize(sp - C);
            float lat = dot(n, np);
            float warp = vnoise3(n * 5.0 + vec3(0.0, 0.0, frameTimeCounter * 0.02)) * 0.07
                       + vnoise3(n * 11.0 + 3.0) * 0.025;
            float l2 = lat + warp;
            float bnd = vnoise(vec2(l2 * 7.0, 0.5)) * 0.50
                      + vnoise(vec2(l2 * 19.0 + 3.0, 1.5)) * 0.32
                      + vnoise(vec2(l2 * 52.0, 2.5)) * 0.18;
            vec3 alb = mix(vec3(0.20, 0.13, 0.08), vec3(0.62, 0.45, 0.27), smoothstep(0.18, 0.55, bnd));
            alb = mix(alb, vec3(0.93, 0.80, 0.58), smoothstep(0.50, 0.85, bnd));

            // the rings cast a shadow band onto the planet
            float denL = dot(Lp, np);
            float dL = (abs(denL) > 1e-4) ? denL : 1e-4;
            float tS = -dot(sp - C, np) / dL;
            vec3 qv = (sp - C) + Lp * tS;
            float rq = length(qv);
            float rsh = 1.0;
            if (tS > 0.0 && rq > R1 && rq < R2) {
                float uq = (rq - R1) / (R2 - R1);
                float rdens = (0.35 + 0.65 * vnoise(vec2(uq * 70.0, 3.3)))
                            * smoothstep(0.0, 0.05, uq) * (1.0 - smoothstep(0.93, 1.0, uq))
                            * smoothstep(0.02, 0.05, abs(uq - 0.58));
                rsh = 1.0 - rdens * 0.85;
            }
            float dl = dot(n, Lp);
            float lit = smoothstep(-0.10, 0.45, dl) * rsh;
            float rim = pow(1.0 - clamp(dot(n, -dir), 0.0, 1.0), 3.0);
            pcol = alb * (lit * 1.15 + 0.012) + vec3(1.0, 0.80, 0.55) * rim * smoothstep(-0.2, 0.5, dl) * 0.30;
        }
    }

    float tr = 1e9;
    vec4 ring = vec4(0.0);
    float den = dot(dir, np);
    if (abs(den) > 1e-4) {
        float t = dot(C, np) / den;
        if (t > 0.0) {
            vec3 rv = dir * t - C;
            float rr = length(rv);
            if (rr > R1 && rr < R2) {
                float u = (rr - R1) / (R2 - R1);
                float dens = smoothstep(0.0, 0.035, u) * (1.0 - smoothstep(0.94, 1.0, u));
                dens *= (0.40 + 0.60 * vnoise(vec2(u * 78.0, 3.3))) * (0.65 + 0.35 * vnoise(vec2(u * 190.0, 7.7)));
                dens *= smoothstep(0.018, 0.045, abs(u - 0.58));          // Cassini-like gap
                float s = dot(rv, Lp);
                float perp = length(rv - Lp * s);
                float shade = (s < 0.0) ? smoothstep(Rp * 0.97, Rp * 1.04, perp) : 1.0;
                vec3 rc = mix(vec3(0.50, 0.40, 0.30), vec3(0.93, 0.84, 0.70), vnoise(vec2(u * 40.0, 1.1)));
                ring = vec4(rc * (0.04 + 1.0 * shade), dens * 0.80);
                tr = t;
            }
        }
    }
    if (pHit) col = pcol;
    if (ring.a > 0.0 && (!pHit || tr < tp)) col = mix(col, ring.rgb, ring.a);
    return col;
}

// Interstellar-inspired End atmosphere: dark upper sky, warm low haze, sparse stars, the planet.
// ---------------------------------------------------------------- the solar system (no Earth, no Moon)
vec3 rotAxis(vec3 v, vec3 ax, float a) {
    return v * cos(a) + cross(ax, v) * sin(a) + ax * dot(ax, v) * (1.0 - cos(a));
}

// kind: 0 Mercury, 1 Venus, 2 Mars, 3 Jupiter, 4 Uranus, 5 Neptune
// Each world is lit by the black hole and has its real colours and signature features.
vec3 solarPlanet(vec3 dir, vec3 col, vec3 bh, vec3 right, vec3 up,
                 float psi, float phi, float Dp, float Rp, int kind, float tilt) {
    vec3 Pd = normalize(bh * cos(psi) + (right * cos(phi) + up * sin(phi)) * sin(psi));
    float angR = asin(Rp / Dp);
    if (dot(dir, Pd) < cos(angR * 1.35)) return col;

    vec3 C = Pd * Dp;
    vec3 Lp = normalize(bh * BH_D - C);
    float bq = dot(dir, C);
    float disc = bq * bq - (dot(C, C) - Rp * Rp);

    // atmosphere colour / strength per world
    vec3 atmC = vec3(0.0);
    float atmS = 0.0;
    if (kind == 1) { atmC = vec3(1.00, 0.90, 0.62); atmS = 0.40; }
    if (kind == 2) { atmC = vec3(0.95, 0.62, 0.42); atmS = 0.08; }
    if (kind == 3) { atmC = vec3(1.00, 0.82, 0.58); atmS = 0.18; }
    if (kind == 4) { atmC = vec3(0.60, 0.95, 1.00); atmS = 0.38; }
    if (kind == 5) { atmC = vec3(0.35, 0.55, 1.00); atmS = 0.45; }

    if (disc <= 0.0) {                                   // thin limb glow just outside the disk
        if (atmS > 0.0) {
            float h = sqrt(max(dot(C, C) - bq * bq, 0.0));
            float outside = (h - Rp) / Rp;
            if (outside < 0.15 && bq > 0.0) {
                vec3 nl = normalize(dir * bq - C);
                col += atmC * atmS * exp(-outside * 45.0) * smoothstep(-0.2, 0.5, dot(nl, Lp)) * 0.5;
            }
        }
        return col;
    }
    float tp = bq - sqrt(disc);
    if (tp <= 0.0) return col;

    vec3 n = normalize(dir * tp - C);
    vec3 ax = normalize(up * cos(tilt) + right * sin(tilt));
    vec3 hlp = (abs(ax.y) < 0.9) ? vec3(0.0, 1.0, 0.0) : vec3(1.0, 0.0, 0.0);
    vec3 e1 = normalize(cross(ax, hlp));
    vec3 e2 = cross(ax, e1);
    float lat = dot(n, ax);
    float lon = atan(dot(n, e2), dot(n, e1));
    float t = frameTimeCounter;
    vec3 alb = vec3(0.5);

    if (kind == 0) {                                     // Mercury: grey-brown, cratered, dark maria
        vec3 nr = rotAxis(n, ax, t * 0.0008);
        float cr = 0.0;
        for (int k = 0; k < 3; k++) {
            float s = (k == 0) ? 6.0 : ((k == 1) ? 14.0 : 32.0);
            float wgt = (k == 0) ? 1.0 : ((k == 1) ? 0.6 : 0.35);
            vec3 p = nr * s;
            vec3 id = floor(p);
            vec3 f = fract(p) - 0.5;
            vec3 off = (vec3(hash13(id + 1.7), hash13(id + 3.1), hash13(id + 5.3)) - 0.5) * 0.5;
            float d = length(f - off);
            float ex = step(0.55, hash13(id));
            cr += ex * wgt * (-(1.0 - smoothstep(0.0, 0.24, d)) * 0.20 + exp(-sq((d - 0.27) * 18.0)) * 0.12);
        }
        float maria = smoothstep(0.50, 0.66, fbm3(nr * 2.0 + 3.0));
        alb = vec3(0.53, 0.47, 0.41) * (0.80 + 0.45 * fbm3(nr * 3.5));
        alb = mix(alb, alb * 0.55, maria * 0.75) + cr * 1.1;
        alb = clamp(alb, 0.0, 1.0) * 0.78;
    } else if (kind == 1) {                              // Venus: pale yellow-white sulphuric cloud deck
        vec3 nr = rotAxis(n, ax, t * 0.002);
        vec3 w = vec3(fbm3(nr * 2.2 + 1.0), fbm3(nr * 2.2 + 5.0), fbm3(nr * 2.2 + 9.0)) - 0.5;
        float sw = fbm3(nr * vec3(2.0, 5.0, 2.0) + w * 2.4);
        alb = mix(vec3(0.90, 0.80, 0.55), vec3(0.98, 0.94, 0.82), smoothstep(0.3, 0.7, sw));
        alb = mix(alb, vec3(0.80, 0.68, 0.42), smoothstep(0.58, 0.80, sw) * 0.35);
    } else if (kind == 2) {                              // Mars: rust red, dark basalt regions, white polar caps
        vec3 nr = rotAxis(n, ax, t * 0.0015);
        float f1 = fbm3(nr * 3.0 + 4.0);
        float f2 = fbm3(nr * 7.0 + 11.0);
        alb = mix(vec3(0.66, 0.32, 0.17), vec3(0.82, 0.52, 0.30), smoothstep(0.45, 0.70, f1));
        alb = mix(alb, vec3(0.28, 0.17, 0.12), smoothstep(0.46, 0.64, f1 * 0.55 + f2 * 0.45) * 0.88);
        float cap = smoothstep(0.962, 0.985, abs(lat) + (f2 - 0.5) * 0.03);
        alb = mix(alb, vec3(0.93, 0.94, 0.96), cap);
    } else if (kind == 3) {                              // Jupiter: cream zones, ochre belts, Great Red Spot
        float lr = lon + t * 0.004;
        float warp = (fbm3(vec3(cos(lr) * 2.5, sin(lr) * 2.5, lat * 5.0)) - 0.5) * 0.10;
        float l2 = lat + warp;
        float b = vnoise(vec2(l2 * 9.0, 0.5)) * 0.55 + vnoise(vec2(l2 * 23.0 + 3.0, 1.5)) * 0.30
                + vnoise(vec2(l2 * 55.0, 2.5)) * 0.15;
        alb = mix(vec3(0.60, 0.39, 0.25), vec3(0.92, 0.84, 0.70), smoothstep(0.35, 0.65, b));
        alb = mix(alb, vec3(0.44, 0.29, 0.21), smoothstep(0.72, 0.92, b) * 0.55);
        float sl = -0.30;
        float lonS = 0.9 + t * 0.004;
        vec3 sc = normalize(e1 * cos(lonS) * sqrt(1.0 - sl * sl) + e2 * sin(lonS) * sqrt(1.0 - sl * sl) + ax * sl);
        vec3 lonDir = normalize(cross(ax, sc));
        vec3 latDir = normalize(cross(sc, lonDir));
        float gx = dot(n, lonDir) / 0.26;
        float gy = dot(n, latDir) / 0.14;
        float grs = (dot(n, sc) > 0.0) ? 1.0 - smoothstep(0.55, 1.0, sqrt(gx * gx + gy * gy)) : 0.0;
        alb = mix(alb, vec3(0.74, 0.27, 0.15), grs * 0.95);
    } else if (kind == 4) {                              // Uranus: pale cyan methane haze, brighter toward the pole
        float bnd = vnoise(vec2(lat * 8.0, 2.0));
        alb = mix(vec3(0.38, 0.70, 0.80), vec3(0.58, 0.85, 0.91), smoothstep(-0.2, 0.9, abs(lat)));
        alb *= 0.96 + 0.06 * bnd;
    } else {                                             // Neptune: deep azure, Great Dark Spot, white cirrus
        float lr = lon + t * 0.003;
        float bnd = vnoise(vec2(lat * 7.0, 5.0)) * 0.6 + vnoise(vec2(lat * 19.0, 8.0)) * 0.4;
        alb = mix(vec3(0.08, 0.18, 0.70), vec3(0.17, 0.34, 0.88), smoothstep(0.3, 0.7, bnd));
        float sl = -0.32;
        float lonS = 2.2 + t * 0.003;
        vec3 sc = normalize(e1 * cos(lonS) * sqrt(1.0 - sl * sl) + e2 * sin(lonS) * sqrt(1.0 - sl * sl) + ax * sl);
        vec3 lonDir = normalize(cross(ax, sc));
        vec3 latDir = normalize(cross(sc, lonDir));
        float gx = dot(n, lonDir) / 0.22;
        float gy = dot(n, latDir) / 0.12;
        float gds = (dot(n, sc) > 0.0) ? 1.0 - smoothstep(0.6, 1.0, sqrt(gx * gx + gy * gy)) : 0.0;
        alb = mix(alb, vec3(0.06, 0.10, 0.42), gds * 0.85);
        float cirrus = smoothstep(0.78, 0.92, fbm3(vec3(cos(lr) * 6.0, sin(lr) * 6.0, lat * 26.0)))
                     * (1.0 - smoothstep(0.0, 0.35, abs(lat + 0.32)));
        alb = mix(alb, vec3(0.92, 0.96, 1.00), cirrus * 0.6);
    }

    float dl = dot(n, Lp);
    float soft = (kind == 0) ? 0.08 : ((kind == 2) ? 0.15 : 0.40);          // thick atmospheres scatter past the terminator
    float lit = smoothstep(-soft, soft + 0.35, dl);
    float mu = clamp(dot(n, -dir), 0.0, 1.0);
    float limbDark = (kind == 0 || kind == 2) ? 1.0 : mix(0.55, 1.0, sqrt(mu));
    float rim = pow(1.0 - mu, 3.0);
    return alb * (lit * 1.15 * limbDark + 0.01) + atmC * rim * atmS * smoothstep(-0.2, 0.5, dl);
}

vec3 solarSystem(vec3 dir, vec3 col, vec3 bh) {
    vec3 right, up;
    bhFrame(bh, right, up);
    col = solarPlanet(dir, col, bh, right, up, 1.48, 2.30, 70.0, 9.00, 3, 0.55);   // Jupiter
    col = solarPlanet(dir, col, bh, right, up, 1.06, 2.94, 60.0, 3.20, 4, 1.70);   // Uranus
    col = solarPlanet(dir, col, bh, right, up, 1.90, 1.61, 62.0, 3.10, 5, 0.50);   // Neptune
    col = solarPlanet(dir, col, bh, right, up, 0.95, 1.11, 14.0, 0.45, 2, 0.43);   // Mars
    col = solarPlanet(dir, col, bh, right, up, 1.57, 0.34, 16.0, 0.80, 1, 0.10);   // Venus
    col = solarPlanet(dir, col, bh, right, up, 0.89, 2.15, 12.0, 0.34, 0, 0.00);   // Mercury
    return col;
}

// stars / haze / nebula only (no planet)
vec3 endSpace(vec3 dir) {
    vec3 bh = BH_DIR;
    float t = frameTimeCounter;
    float up = dir.y;
    vec3 haze = mix(vec3(0.075, 0.066, 0.059), vec3(0.15, 0.134, 0.115), smoothstep(-0.3, 0.25, up));
    haze += vec3(1.0, 0.74, 0.48) * pow(max(dot(dir, bh), 0.0), 7.0) * 0.065;
    vec3 space = mix(vec3(0.056, 0.060, 0.078), vec3(0.009, 0.012, 0.025), smoothstep(0.0, 0.9, up));
    vec3 col = mix(haze, space, smoothstep(0.04, 0.80, up));
    float neb = fbm3(dir * 4.0 + vec3(0.0, 0.0, t * 0.001));
    float neb2 = fbm3(dir * 8.0 + 9.0);
    col += mix(vec3(0.035, 0.045, 0.075), vec3(0.075, 0.045, 0.055), neb2)
         * smoothstep(0.47, 0.78, neb) * smoothstep(0.08, 0.58, up) * 0.34;
    float sv = smoothstep(0.02, 0.48, up);
    col += (starLayer(dir, 150.0, 0.991, 0.17, 0.0, t, 0.35) * 1.25
          + starLayer(dir, 310.0, 0.992, 0.14, 31.0, t, 0.35) * 0.72) * sv;
    col += shootingStars(dir, t) * 0.35;
    return col;
}

vec3 endBackground(vec3 dir) {
    vec3 col = endSpace(dir);
#ifdef END_PLANET
    col = planetLayer(dir, col, BH_DIR);
#endif
#ifdef END_PLANETS
    col = solarSystem(dir, col, BH_DIR);
#endif
    return col;
}

vec3 endFog(vec3 dir) {
    vec3 c = mix(vec3(0.095, 0.082, 0.070), vec3(0.20, 0.17, 0.14), smoothstep(-0.3, 0.3, dir.y));
    c += vec3(1.0, 0.78, 0.52) * pow(max(dot(dir, BH_DIR), 0.0), 7.0) * 0.10;
    return c;
}

// ---------------------------------------------------------------- Gargantua
// Exact Schwarzschild null geodesics in Cartesian form  d2x/dl2 = -1.5 rs h^2 x / r^5
// (h = |x cross v| is conserved). The shadow, photon ring and the disk bent over and under the
// hole all emerge from the integration; nothing is painted on.
vec3 bhDiskColor(float prof) {
    vec3 base = mix(vec3(0.95, 0.20, 0.04), vec3(1.0, 0.55, 0.20), smoothstep(0.10, 0.55, prof));
    base = mix(base, vec3(1.0, 0.82, 0.55), smoothstep(0.50, 0.85, prof));
    return mix(base, vec3(1.0, 0.95, 0.85), smoothstep(0.85, 1.0, prof) * 0.7);
}

vec3 getEndSky(vec3 dir) {
#ifndef BLACK_HOLE
    return endBackground(dir);
#else
    vec3 bh = BH_DIR;
    float c = dot(dir, bh);
    if (c < 0.05) return endBackground(dir);

    vec3 right, up;
    bhFrame(bh, right, up);
    vec2 q = vec2(dot(dir, right), dot(dir, up)) / c;
    float b = length(q);

    // weak-field lens equation outside the marched region (continuous with the marched result)
    float tE2 = 2.0 * BH_RS / BH_D;
    vec2 beta = q - tE2 * q / max(b * b, 1e-4);
    vec3 outer = endBackground(normalize(bh + right * beta.x + up * beta.y));
    if (b > 0.60) return outer;

    // world-locked disk frame: inclination measured from the line of sight, then rolled
    vec3 o = -bh;
    vec3 u0 = vec3(0.0, 1.0, 0.0) - o * o.y;
    if (dot(u0, u0) < 1e-5) u0 = vec3(1.0, 0.0, 0.0) - o * o.x;
    u0 = normalize(u0);
    float roll = radians(float(BH_ROLL));
    vec3 uu = u0 * cos(roll) + cross(o, u0) * sin(roll);
    float inc = radians(float(BH_INCLINATION));
    vec3 nd = normalize(o * cos(inc) + uu * sin(inc));
    vec3 d1 = normalize(cross(nd, bh));
    vec3 d2 = cross(nd, d1);

    vec3 pos = -bh * BH_D;
    vec3 vel = dir;
    vec3 cr = cross(pos, vel);
    float h2 = dot(cr, cr);
    float bimp = sqrt(h2);
    vec3 acc = vec3(0.0);
    float T = 1.0;
    bool cap = false;

    for (int i = 0; i < BH_STEPS; i++) {
        float r = length(pos);
        if (r < BH_RS) { cap = true; break; }
        if (r > 46.0 && dot(pos, vel) > 0.0) break;
        float dt = clamp(0.07 * r, 0.04, 2.5);
        vec3 prev = pos;
        vel += -1.5 * BH_RS * h2 * pos / (r * r * r * r * r) * dt;
        pos += vel * dt;

        float s0 = dot(prev, nd);
        float s1 = dot(pos, nd);
        if (s0 * s1 < 0.0) {                                  // crossed the disk plane this step
            vec3 hp = mix(prev, pos, s0 / (s0 - s1));
            float rho = length(hp);
            if (rho > BH_RIN && rho < BH_ROUT) {
                float phi = atan(dot(hp, d2), dot(hp, d1));
                float ph = phi - frameTimeCounter * 0.35 * pow(BH_RIN / rho, 1.5);   // Keplerian shear
                float tu = vnoise3(vec3(cos(ph) * 2.5, sin(ph) * 2.5, rho * 0.55));
                float tu2 = vnoise3(vec3(cos(ph * 2.0 + 1.0) * 5.0, sin(ph * 2.0 + 1.0) * 5.0, rho * 1.3 + 7.0));
                float rings = vnoise(vec2(rho * 4.0, 1.3)) * 0.55 + vnoise(vec2(rho * 13.0, 4.1)) * 0.45;
                float dens = 0.55 + 0.30 * rings + 0.28 * (tu - 0.5) + 0.16 * (tu2 - 0.5);
                float xr = rho / BH_RIN;
                float edge = smoothstep(1.0, 1.06, xr) * (1.0 - smoothstep(0.55, 1.0, (rho - BH_RIN) / (BH_ROUT - BH_RIN)));
                float emis = pow(1.0 / xr, 2.6);

                // orbital Doppler beaming + gravitational redshift: g = sqrt(1-rs/r) / (gamma (1 - beta.n))
                float vorb = sqrt(0.5 * BH_RS / max(rho - BH_RS, 0.1));
                vec3 vd = normalize(cross(nd, hp)) * vorb;
                float gam = inversesqrt(max(1.0 - dot(vd, vd), 0.05));
                float dopp = 1.0 / (gam * (1.0 + dot(vd, normalize(vel))));
                float gr = sqrt(max(1.0 - BH_RS / rho, 0.0));
                float g = max(dopp * gr, 0.0);
                float inten = 3.4 * emis * dens * edge * g * g * g * BH_BRIGHTNESS;

                vec3 col = bhDiskColor(1.0 / xr);
                float lb = luma(col);
                col = mix(col, vec3(1.0, 0.88, 0.75) * lb * 1.2, clamp((g - 1.0) * 0.6, 0.0, 0.4));   // approaching: hotter
                col = mix(col, col * vec3(1.0, 0.50, 0.30), clamp(1.0 - g, 0.0, 0.5));                // receding: redder

                float alpha = clamp(edge * (0.55 + 0.45 * dens), 0.0, 1.0) * 0.9;
                acc += T * col * inten;
                T *= 1.0 - alpha;
                if (T < 0.02) break;
            }
        }
    }

    vec3 bg = cap ? vec3(0.0) : endSpace(normalize(vel));   // no ghost image of the planet beside the hole
    float bc = 2.598 * BH_RS;                                 // critical impact parameter
    float x = (bimp - bc) / (0.028 * bc);
    float photon = exp(-x * x);
    float halo = exp(-3.0 * max(bimp / bc - 1.0, 0.0)) * 0.03 * smoothstep(0.92, 1.0, bimp / bc);   // none inside the shadow
    acc = min(acc, vec3(14.0));
    vec3 res = acc + bg * T
             + vec3(1.0, 0.86, 0.66) * photon * 0.9 * BH_BRIGHTNESS * T
             + vec3(1.0, 0.55, 0.28) * halo * T;
    return min(mix(res, outer, smoothstep(0.44, 0.60, b)), vec3(18.0));
#endif
}

// ---------------------------------------------------------------- the Nether
// neutral warm Nether base with only a gentle hint of the biome's fog colour
vec3 getNetherFog() {
    vec3 c = pow(fogColor, vec3(1.6)) * 8.0;
    c = mix(vec3(luma(c)), c, 0.45);
    return vec3(0.17, 0.08, 0.045) + c * 0.40;
}
vec3 getNetherTint() {
    vec3 c = pow(fogColor, vec3(1.6)) * 1.2;
    return mix(vec3(luma(c)), c, 0.40) * 0.6;
}
#endif
