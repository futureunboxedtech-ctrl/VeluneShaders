#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/wind.glsl"

#ifdef USE_BLOCK_ID
in vec4 mc_Entity;
in vec2 mc_midTexCoord;
#endif

out vec2 texcoord;
out vec2 lmcoord;
out vec4 glcolor;
out vec3 normalV;
out vec3 viewPos;
flat out float blockId;

void main() {
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    glcolor  = gl_Color;
    normalV  = normalize(gl_NormalMatrix * gl_Normal);
    vec4 vp  = gl_ModelViewMatrix * gl_Vertex;
    blockId  = 0.0;
#ifdef USE_BLOCK_ID
    blockId = mc_Entity.x;
    #ifdef WAVING_PLANTS
    if (blockId > 10001.5) {
        vec3 feet = (gbufferModelViewInverse * vp).xyz;
        float top = float(gl_MultiTexCoord0.t < mc_midTexCoord.t);
        feet += windOffset(feet + cameraPosition, blockId, top);
        vp = gbufferModelView * vec4(feet, 1.0);
    }
    #endif
#endif
    viewPos = vp.xyz;
    gl_Position = gl_ProjectionMatrix * vp;
}
