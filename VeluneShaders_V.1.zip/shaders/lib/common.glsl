#ifndef COMMON_GLSL
#define COMMON_GLSL

#define PI 3.14159265359
#define TAU 6.28318530718

// ======================= OPTIONS =======================
#define SHADOW_RES 2048 //[1024 2048 3072 4096]
#define SHADOW_DIST 128.0 //[64.0 96.0 128.0 192.0 256.0]
#define SHADOW_SOFT 1.0 //[0.5 0.75 1.0 1.5 2.0]
#define SUN_INTENSITY 3.2 //[2.0 2.6 3.2 4.0 5.0]
#define SUN_TILT -30.0 //[-45.0 -30.0 -15.0 0.0 15.0 30.0 45.0]
#define WAVING_PLANTS
#define VOLUMETRIC_LIGHT
#define VL_STRENGTH 1.0 //[0.25 0.5 1.0 1.5 2.0 3.0]
#define VL_STEPS 16 //[8 12 16 24 32]
#define FOG_DENSITY 1.0 //[0.0 0.5 1.0 1.5 2.0 3.0]
#define WATER_WAVES 1.0 //[0.4 0.7 1.0 1.4 2.0]
#define WATER_SPEED 1.0 //[0.5 1.0 1.5 2.0]
#define WATER_DENSITY 1.0 //[0.5 1.0 1.5 2.0]
#define WATER_SSR
#define SSR_STEPS 24 //[12 16 24 32]
#define BLOOM
#define BLOOM_STRENGTH 0.30 //[0.1 0.2 0.3 0.4 0.6 0.8]
#define EXPOSURE 1.0 //[0.6 0.8 1.0 1.2 1.5 2.0]
#define SATURATION 1.10 //[0.8 0.9 1.0 1.1 1.2 1.4]
#define VIGNETTE
#define FXAA
#define SUNSET_INTENSITY 1.0 //[0.5 0.75 1.0 1.25 1.5]
#define AURORA
#define PUDDLES
#define CLOUD_COVERAGE 0.5 //[0.3 0.4 0.5 0.6 0.7]
#define COLORED_LIGHT
#define LIGHT_BLEED 1.0 //[0.5 1.0 1.5 2.0]
#define SNOW_SPARKLE
#define FIREFLIES
#define BLACK_HOLE
#define END_PLANET
#define END_PLANETS
// ---- End black hole ----
#define BH_LOCK_LIGHT                 // black hole sits where the End's shadow light is (shadows point away from it)
#define BH_WORLD_X 0.00 //[-1.0 -0.5 0.0 0.5 1.0]
#define BH_WORLD_Y 0.36 //[-0.5 0.0 0.2 0.36 0.5 0.7 1.0]
#define BH_WORLD_Z 0.93 //[-1.0 -0.5 0.0 0.5 0.93 1.0]
#define BH_DIST 26 //[20 24 26 30 36 44]
#define BH_STEPS 112 //[48 72 96 112 128]
#define BH_BRIGHTNESS 1.0 //[0.5 0.75 1.0 1.25 1.5 2.0]
#define BH_INCLINATION 82 //[70 75 80 82 85 88]
#define BH_ROLL -14 //[-45 -30 -14 0 14 30 45]
#define LENS_FLARE
//#define MOTION_BLUR
//#define DOF
#define DOF_STRENGTH 1.0 //[0.5 1.0 1.5 2.0]
// =======================================================

// dimension selection: world-1/ and world1/ folders define DIM_NETHER / DIM_END
#if !defined(DIM_NETHER) && !defined(DIM_END)
#define DIM_OVERWORLD
#endif

float sq(float x) { return x * x; }
float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

float hash12(vec2 p) {
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}
float hash13(vec3 p3) {
    p3 = fract(p3 * 0.1031);
    p3 += dot(p3, p3.zyx + 31.32);
    return fract((p3.x + p3.y) * p3.z);
}
float vnoise(vec2 p) {
    vec2 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash12(i), hash12(i + vec2(1, 0)), f.x),
               mix(hash12(i + vec2(0, 1)), hash12(i + vec2(1, 1)), f.x), f.y);
}
float vnoise3(vec3 p) {
    vec3 i = floor(p), f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = mix(hash13(i), hash13(i + vec3(1, 0, 0)), f.x);
    float b = mix(hash13(i + vec3(0, 1, 0)), hash13(i + vec3(1, 1, 0)), f.x);
    float c = mix(hash13(i + vec3(0, 0, 1)), hash13(i + vec3(1, 0, 1)), f.x);
    float d = mix(hash13(i + vec3(0, 1, 1)), hash13(i + vec3(1, 1, 1)), f.x);
    return mix(mix(a, b, f.y), mix(c, d, f.y), f.z);
}
float fbm3(vec3 p) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < 4; i++) { s += a * vnoise3(p); p *= 2.03; a *= 0.5; }
    return s;
}
float fbm2(vec2 p) {
    float a = 0.5, s = 0.0;
    for (int i = 0; i < 4; i++) { s += a * vnoise(p); p = p * 2.03 + vec2(17.0, 5.0); a *= 0.5; }
    return s;
}
float ign(vec2 p) { return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715)))); }

#endif
