#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
in vec2 texcoord;
in vec4 glcolor;
void main() {
    vec4 c = texture(gtexture, texcoord) * glcolor;
    if (c.a < 0.05) discard;
    gl_FragData[0] = vec4(pow(c.rgb, vec3(2.2)) * 2.5, c.a);
}
