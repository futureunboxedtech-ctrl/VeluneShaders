// requires common.glsl + uniforms.glsl
#ifndef SHADOW_GLSL
#define SHADOW_GLSL

#define SHADOW_BIAS 0.85

float shadowDistortFactor(vec2 xy) { return length(xy) * SHADOW_BIAS + (1.0 - SHADOW_BIAS); }
vec3 shadowClip(vec3 feet) {
    vec4 c = shadowProjection * (shadowModelView * vec4(feet, 1.0));
    return c.xyz / c.w;
}
vec3 distortToUV(vec3 c) {
    c.xy /= shadowDistortFactor(c.xy);
    return c * 0.5 + 0.5;
}

const vec2 POISSON[8] = vec2[8](
    vec2(-0.613392, 0.617481), vec2(0.170019, -0.040254),
    vec2(-0.299417, 0.791925), vec2(0.645680, 0.493210),
    vec2(-0.651784, 0.717887), vec2(0.421003, 0.027070),
    vec2(-0.817194, -0.271096), vec2(-0.705374, -0.668203));

// coloured, soft shadow. returns RGB visibility of the light
vec3 getShadow(vec3 feet, vec3 nW, float NdotL, float noise) {
    vec3 c0 = shadowClip(feet);
    float df = shadowDistortFactor(c0.xy);
    float off = (0.05 + 0.20 * (1.0 - NdotL)) * (0.3 + 0.7 * df);
    vec3 sc = distortToUV(shadowClip(feet + nW * off));
    sc.z -= 0.0005;
    float fade = smoothstep(0.80, 0.98, max(abs(c0.x), abs(c0.y)));
    if (sc.x <= 0.0 || sc.y <= 0.0 || sc.x >= 1.0 || sc.y >= 1.0 || sc.z >= 1.0) return vec3(1.0);

    float a = noise * TAU;
    float ca = cos(a), sa = sin(a);
    mat2 rot = mat2(ca, sa, -sa, ca);
    float rad = 2.5 * SHADOW_SOFT / float(SHADOW_RES);
    float s0 = 0.0, s1 = 0.0;
    for (int i = 0; i < 8; i++) {
        vec2 o = rot * POISSON[i] * rad;
        s0 += step(sc.z, texture(shadowtex0, sc.xy + o).r);
        s1 += step(sc.z, texture(shadowtex1, sc.xy + o).r);
    }
    s0 *= 0.125; s1 *= 0.125;
    vec4 scol = texture(shadowcolor0, sc.xy);
    vec3 tint = mix(vec3(1.0), scol.rgb, scol.a);
    vec3 res = s1 * mix(tint, vec3(1.0), s0);
    return mix(res, vec3(1.0), fade);
}

// cheap single-tap opaque visibility (volumetric light)
float shadowVisibility(vec3 feet) {
    vec3 sc = distortToUV(shadowClip(feet));
    if (sc.x <= 0.0 || sc.y <= 0.0 || sc.x >= 1.0 || sc.y >= 1.0) return 1.0;
    return step(sc.z - 0.0008, texture(shadowtex1, sc.xy).r);
}
#endif
