#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/atmos.glsl"
#include "/lib/shadow.glsl"
#include "/lib/water.glsl"

in vec2 texcoord;
in vec2 lmcoord;
in vec4 glcolor;
in vec3 normalV;
in vec3 viewPos;
flat in float blockId;

void main() {
    vec4 tex = texture(gtexture, texcoord);
    vec3 albedo = tex.rgb;
    float alpha = tex.a;
    float ao = 1.0;

#if defined(PASS_CLOUDS)
    albedo = vec3(0.92);
    alpha = 0.88;
#elif defined(PASS_TERRAIN) || defined(PASS_WATER)
    albedo *= glcolor.rgb;
    ao = glcolor.a;
#else
    albedo *= glcolor.rgb;
    alpha *= glcolor.a;
#endif

#if defined(PASS_WEATHER)
    alpha *= 0.55;
#endif

#ifdef PASS_WATER
    if (alpha < 0.02) discard;
#else
    if (alpha < 0.1) discard;
#endif

#ifdef PASS_ENTITY
    albedo = mix(albedo, entityColor.rgb, entityColor.a);
#endif
    albedo = pow(max(albedo, vec3(0.0)), vec3(2.2));

    // ---------- geometry ----------
    vec3 feet = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    vec3 nV = normalize(normalV);
#if defined(PASS_CLOUDS)
    nV = normalize(cross(dFdx(viewPos), dFdy(viewPos)));
    if (dot(nV, viewPos) > 0.0) nV = -nV;
#elif defined(PASS_PARTICLE) || defined(PASS_WEATHER)
    nV = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
#endif
    vec3 nW = normalize(mat3(gbufferModelViewInverse) * nV);

    vec2 lm = clamp((lmcoord - 0.0313) / 0.9375, 0.0, 1.0);
#if defined(PASS_CLOUDS)
    lm = vec2(0.0, 1.0);
#endif

    // ---------- water surface: write normal + mask, shaded in composite ----------
#if defined(PASS_WATER)
    bool isWater = abs(blockId - 10001.0) < 0.5;
    if (isWater) {
        vec3 wp = feet + cameraPosition;
        float dd = length(viewPos);
        float fadeS = mix(1.0, 0.3, smoothstep(30.0, 160.0, dd));
        vec3 wn = waterNormalW(wp.xz, frameTimeCounter * WATER_SPEED, WATER_WAVES * fadeS);
        vec2 rr = rainRipples(wp.xz, frameTimeCounter) * rainStrength * 0.8;
        wn = normalize(wn + vec3(rr.x, 0.0, rr.y));
        vec3 nWW = (nW.y > 0.5) ? wn : nW;
        vec3 nVW = normalize(mat3(gbufferModelView) * nWW);
        gl_FragData[0] = vec4(0.0);
        gl_FragData[1] = vec4(nVW * 0.5 + 0.5, 1.0);
        gl_FragData[2] = vec4(1.0, lm.y, 0.0, 1.0);
        return;
    }
#endif

    // ---------- light sources per dimension ----------
    vec3 sunDirW = vec3(0.0, 1.0, 0.0);
    vec3 lDirW = vec3(0.0, 1.0, 0.0);
    vec3 lightC = vec3(0.0);
    vec3 skyA = vec3(0.0);
#if defined(DIM_NETHER)
    // no directional light: lava-lit from below, tinted by biome fog
#elif defined(DIM_END)
    lDirW = bhDir();
    lightC = endLightColor();   // the black hole is the sun here
#else
    sunDirW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    lDirW   = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    lightC  = getLightColor(sunDirW);
    skyA    = getSkyAmbient(sunDirW);
#endif

    float NdotL = dot(nW, lDirW);
#if defined(PASS_PARTICLE) || defined(PASS_WEATHER)
    NdotL = 0.7;
#endif
    float diff = clamp(NdotL, 0.0, 1.0);
#ifdef USE_BLOCK_ID
    if (abs(blockId - 10002.0) < 0.5) diff = 0.7;
    if (abs(blockId - 10003.0) < 0.5) diff = max(diff, 0.35);
#endif

    vec3 shadow = vec3(1.0);
#if (defined(DIM_OVERWORLD) || defined(DIM_END)) && !defined(PASS_CLOUDS) && !defined(PASS_WEATHER)
    if (diff > 0.0) {
        shadow = getShadow(feet, nW, diff, ign(gl_FragCoord.xy));
#ifdef DIM_OVERWORLD
        shadow *= smoothstep(0.20, 0.80, lm.y);
#endif
    } else {
        shadow = vec3(0.0);
    }
#endif

    // ---------- ambient + block light ----------
    float hemi = nW.y * 0.5 + 0.5;
#if defined(DIM_NETHER)
    vec3 amb = (mix(vec3(0.27, 0.11, 0.06), vec3(0.10, 0.055, 0.045), hemi)
                + getNetherTint() + vec3(0.03)) * ao;
    vec3 blockL = vec3(1.0, 0.48, 0.14) * 3.0 * pow(lm.x, 2.5);
    float emisMul = 7.0;
#elif defined(DIM_END)
    vec3 amb = (mix(vec3(0.07, 0.08, 0.10), vec3(0.20, 0.22, 0.27), hemi) + vec3(0.02)) * ao;   // cool grey fill
    vec3 blockL = vec3(1.0, 0.56, 0.24) * 2.4 * pow(lm.x, 3.0);
    float emisMul = 4.0;
#else
    float skyL = lm.y * lm.y;
    vec3 groundA = skyA * 0.30 + vec3(0.02);
    vec3 amb = mix(groundA, skyA, hemi) * skyL + vec3(0.022, 0.025, 0.036);
    amb *= ao;
    vec3 blockL = vec3(1.0, 0.56, 0.24) * 2.4 * pow(lm.x, 3.0);
    float emisMul = 4.0;
    #if defined(PASS_CLOUDS)
    // sunset-lit cloud undersides pick up the horizon colour
    vec3 vd = normalize(feet);
    vec3 hs = getSky(normalize(vec3(vd.x, 0.04, vd.z)), sunDirW);
    amb = mix(amb, hs * 0.9, 0.65 * twilightAmount(sunDirW.y));
    amb += vec3(0.10, 0.14, 0.26) * (1.0 - dayAmount(sunDirW.y));   // silver moonlit clouds
    #endif
#endif

    blockL *= 1.0 + 0.06 * sin(frameTimeCounter * 9.0 + hash13(floor(feet + cameraPosition)) * 40.0);   // torch flicker
    vec3 lit = lightC * diff * shadow + amb + blockL * mix(ao, 1.0, 0.6);
    vec3 color = albedo * lit;

#if defined(PASS_TERRAIN)
    float maxc = max(albedo.r, max(albedo.g, albedo.b));
    float satc = (maxc - min(albedo.r, min(albedo.g, albedo.b))) / max(maxc, 1e-3);
    float e15 = smoothstep(0.96, 1.0, lm.x) * smoothstep(0.5, 0.9, maxc);
    float e14 = smoothstep(0.90, 0.95, lm.x) * smoothstep(0.6, 0.85, maxc) * smoothstep(0.4, 0.6, satc);
    float emis = max(e15, e14);
    color += albedo * emis * emisMul;
#endif

    // ---------- wet surfaces: darker, puddles that mirror the sky, rain rings ----------
#if defined(PASS_TERRAIN) && defined(DIM_OVERWORLD) && defined(PUDDLES)
    if (wetness > 0.01) {
        vec3 wp = feet + cameraPosition;
        float wetFace = smoothstep(0.3, 0.9, nW.y);
        float pud = smoothstep(0.50, 0.60, vnoise(wp.xz * 0.35) * 0.65 + vnoise(wp.xz * 1.3) * 0.35);
        float wet = wetness * smoothstep(0.7, 0.95, lm.y);
        color *= mix(1.0, 0.70, wet * 0.8);
        float pm = wet * wetFace * pud;
        vec2 rp = rainRipples(wp.xz, frameTimeCounter) * rainStrength * pm;
        vec3 nP = normalize(nW + vec3(rp.x, 0.0, rp.y) * 0.6);
        vec3 Vw = normalize(feet);
        vec3 Rp = reflect(Vw, nP);
        float Fp = 0.04 + 0.96 * pow(1.0 - clamp(dot(nP, -Vw), 0.0, 1.0), 5.0);
        vec3 rcol = getSky(Rp, sunDirW) + getCelestials(Rp, sunDirW, false, 2.0);
        color = mix(color, rcol, pm * (0.18 + 0.82 * Fp));
    }
#endif

    // ---------- snow / ice sparkle ----------
#if defined(PASS_TERRAIN) && defined(DIM_OVERWORLD) && defined(SNOW_SPARKLE)
    if (abs(blockId - 10020.0) < 0.5 && diff * shadow.r > 0.1) {
        vec3 cellp = floor((feet + cameraPosition) * 12.0);
        float h = hash13(cellp + floor(frameTimeCounter * 1.5));
        float sp = step(0.994, h);
        float vv = pow(max(dot(reflect(-lDirW, nW), normalize(-feet)), 0.0), 6.0);
        color += lightC * sp * (1.5 + 4.0 * vv) * shadow.r * diff;
    }
#endif

#if defined(DIM_END)
    float ndv = clamp(dot(nV, -normalize(viewPos)), 0.0, 1.0);
    color += albedo * vec3(0.9, 0.8, 0.65) * pow(1.0 - ndv, 3.0) * 0.12;
#endif

    gl_FragData[0] = vec4(color, alpha);
#ifdef PASS_TERRAIN
    gl_FragData[1] = vec4(clamp(albedo * emis, 0.0, 1.0), (abs(blockId - 10030.0) < 0.5) ? 1.0 : 0.0);   // emissive colour + firefly-bush marker
#endif
#ifdef PASS_WATER
    gl_FragData[1] = vec4(nV * 0.5 + 0.5, 1.0);
    gl_FragData[2] = vec4(0.0, lm.y, 0.0, 1.0);
#endif
}
