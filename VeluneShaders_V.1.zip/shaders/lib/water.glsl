#ifndef WATER_GLSL
#define WATER_GLSL
float waveHeight(vec2 p, float t) {
    float h = 0.0, a = 0.5, f = 0.8;
    vec2 d = vec2(0.8, 0.6);
    for (int i = 0; i < 6; i++) {
        float ph = dot(p, d) * f + t * (0.9 + 0.28 * float(i));
        h += a * exp(sin(ph + h * 1.2) - 1.0);
        d = vec2(d.x * 0.8 - d.y * 0.6, d.x * 0.6 + d.y * 0.8);
        a *= 0.5; f *= 1.65;
    }
    return h;
}
vec3 waterNormalW(vec2 p, float t, float strength) {
    float e = 0.02;
    float h0 = waveHeight(p, t);
    float hx = waveHeight(p + vec2(e, 0.0), t);
    float hz = waveHeight(p + vec2(0.0, e), t);
    vec2 g = vec2(hx - h0, hz - h0) / e * 0.45 * strength;
    return normalize(vec3(-g.x, 1.0, -g.y));
}

// expanding rain-drop rings; returns a horizontal normal offset
vec2 rainRipples(vec2 p, float t) {
    vec2 res = vec2(0.0);
    for (int k = 0; k < 2; k++) {
        vec2 q = p * (2.0 + float(k) * 1.3) + float(k) * 17.0;
        vec2 id = floor(q);
        vec2 f = fract(q) - 0.5;
        float h = hash12(id);
        vec2 c = (vec2(hash12(id + 3.3), hash12(id + 7.7)) - 0.5) * 0.5;
        float ph = fract(t * (0.7 + 0.4 * h) + h * 10.0);
        vec2 dv = f - c;
        float d = length(dv);
        float ring = exp(-sq((d - ph * 0.45) * 16.0)) * (1.0 - ph);
        res += dv / max(d, 1e-3) * ring * 0.5;
    }
    return res;
}
#endif
