// requires uniforms.glsl
vec3 windOffset(vec3 wp, float id, float top) {
    float t = frameTimeCounter * 1.5;
    float boost = 1.0 + rainStrength * 1.5;
    float w1 = sin(t + wp.x * 0.8 + wp.z * 0.6);
    float w2 = sin(t * 1.3 + wp.x * 1.7 - wp.z * 1.1 + 1.7);
    float gust = 0.5 + 0.5 * sin(t * 0.4 + wp.x * 0.15 + wp.z * 0.1);
    vec2 d = vec2(w1 * 0.6 + w2 * 0.4, w2 * 0.5 + w1 * 0.3) * (0.4 + 0.6 * gust) * boost;
    if (abs(id - 10002.0) < 0.5) return vec3(d.x, -abs(d.x) * 0.2, d.y) * 0.075 * top;
    if (abs(id - 10003.0) < 0.5) return vec3(d.x, d.y * 0.3, d.y) * 0.03;
    return vec3(0.0);
}
