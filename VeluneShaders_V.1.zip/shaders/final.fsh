#version 330 compatibility
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"

/*
const int colortex0Format = RGBA16F;
const int colortex3Format = RGBA16F;
*/
#ifdef DIM_END
#define SUN_PATH -66.0
#else
#define SUN_PATH SUN_TILT
#endif
const float sunPathRotation = SUN_PATH;
const int shadowMapResolution = SHADOW_RES;
const float shadowDistance = SHADOW_DIST;

in vec2 uv;

void main() {
#ifdef FXAA
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 rgbNW = texture(colortex0, uv + vec2(-1.0, -1.0) * px).rgb;
    vec3 rgbNE = texture(colortex0, uv + vec2( 1.0, -1.0) * px).rgb;
    vec3 rgbSW = texture(colortex0, uv + vec2(-1.0,  1.0) * px).rgb;
    vec3 rgbSE = texture(colortex0, uv + vec2( 1.0,  1.0) * px).rgb;
    vec3 rgbM  = texture(colortex0, uv).rgb;
    float lNW = luma(rgbNW), lNE = luma(rgbNE), lSW = luma(rgbSW), lSE = luma(rgbSE), lM = luma(rgbM);
    float lMin = min(lM, min(min(lNW, lNE), min(lSW, lSE)));
    float lMax = max(lM, max(max(lNW, lNE), max(lSW, lSE)));
    vec2 dir;
    dir.x = -((lNW + lNE) - (lSW + lSE));
    dir.y =  ((lNW + lSW) - (lNE + lSE));
    float dirReduce = max((lNW + lNE + lSW + lSE) * 0.25 * 0.125, 1.0 / 128.0);
    float rcpDirMin = 1.0 / (min(abs(dir.x), abs(dir.y)) + dirReduce);
    dir = clamp(dir * rcpDirMin, vec2(-8.0), vec2(8.0)) * px;
    vec3 rgbA = 0.5 * (texture(colortex0, uv + dir * (1.0 / 3.0 - 0.5)).rgb +
                       texture(colortex0, uv + dir * (2.0 / 3.0 - 0.5)).rgb);
    vec3 rgbB = rgbA * 0.5 + 0.25 * (texture(colortex0, uv + dir * -0.5).rgb +
                                     texture(colortex0, uv + dir * 0.5).rgb);
    float lB = luma(rgbB);
    vec3 col = (lB < lMin || lB > lMax) ? rgbA : rgbB;
    gl_FragColor = vec4(col, 1.0);
#else
    gl_FragColor = vec4(texture(colortex0, uv).rgb, 1.0);
#endif
}
