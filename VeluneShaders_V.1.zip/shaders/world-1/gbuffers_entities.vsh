#version 330 compatibility
#define DIM_NETHER
#define PASS_ENTITY
#include "/lib/lit_vert.glsl"
