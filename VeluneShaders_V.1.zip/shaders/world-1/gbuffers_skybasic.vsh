#version 330 compatibility
#define DIM_NETHER
void main() { gl_Position = ftransform(); }
