#version 330 compatibility
#define DIM_NETHER
/* DRAWBUFFERS:0 */
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
#include "/lib/atmos.glsl"
#include "/lib/shadow.glsl"
#include "/lib/water.glsl"

/*
const int colortex0Format = RGBA16F;
const int colortex3Format = RGBA16F;
*/
const vec4 colortex1ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
const vec4 colortex2ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
#ifdef DIM_END
#define SUN_PATH -66.0
#else
#define SUN_PATH SUN_TILT
#endif
const float sunPathRotation = SUN_PATH;
const int shadowMapResolution = SHADOW_RES;
const float shadowDistance = SHADOW_DIST;
const float ambientOcclusionLevel = 1.0;

in vec2 uv;

vec3 toView(vec2 p, float d) {
    vec4 v = gbufferProjectionInverse * vec4(vec3(p, d) * 2.0 - 1.0, 1.0);
    return v.xyz / v.w;
}
vec3 viewToScreen(vec3 p) {
    vec4 c = gbufferProjection * vec4(p, 1.0);
    return c.xyz / c.w * 0.5 + 0.5;
}

// screen-space reflection against opaque geometry
vec4 traceSSR(vec3 origin, vec3 dir, float dither) {
    float stepLen = 0.5;
    vec3 p = origin + dir * stepLen * dither;
    for (int i = 0; i < SSR_STEPS; i++) {
        p += dir * stepLen;
        if (p.z > -0.05) return vec4(0.0);
        vec3 s = viewToScreen(p);
        if (s.x < 0.0 || s.y < 0.0 || s.x > 1.0 || s.y > 1.0) return vec4(0.0);
        float sd = texture(depthtex1, s.xy).r;
        vec3 sp = toView(s.xy, sd);
        float diff = p.z - sp.z;
        if (sd < 1.0 && diff < 0.0 && diff > -(stepLen * 2.0 + 0.2)) {
            vec3 lo = p - dir * stepLen;
            vec3 hi = p;
            for (int k = 0; k < 5; k++) {
                vec3 mid = (lo + hi) * 0.5;
                vec3 ms = viewToScreen(mid);
                float md = texture(depthtex1, ms.xy).r;
                vec3 mp = toView(ms.xy, md);
                if (mid.z - mp.z < 0.0) hi = mid; else lo = mid;
            }
            vec3 hs = viewToScreen(hi);
            float edge = smoothstep(0.0, 0.08, min(min(hs.x, hs.y), min(1.0 - hs.x, 1.0 - hs.y)));
            return vec4(min(texture(colortex0, hs.xy).rgb, vec3(12.0)), edge);
        }
        stepLen *= 1.16;
    }
    return vec4(0.0);
}

float hgPhase(float c, float g) {
    float g2 = g * g;
    return (1.0 - g2) / (4.0 * PI * pow(1.0 + g2 - 2.0 * g * c, 1.5));
}

// shadow-marched volumetric light ("god rays") from the sun / moon
vec3 volumetric(vec3 dirW, float maxDist, float noise, vec3 lDirW, vec3 lightC,
                float density, float g, vec3 absC, bool uw) {
    float stepLen = maxDist / float(VL_STEPS);
    float cosA = dot(dirW, lDirW);
    float phase = hgPhase(cosA, g) * 0.9 + 0.03;
    vec3 sum = vec3(0.0);
    for (int i = 0; i < VL_STEPS; i++) {
        float t = (float(i) + noise) * stepLen;
        float vis = shadowVisibility(dirW * t);
        vec3 T = uw ? exp(-absC * t) : vec3(exp(-density * t));
        sum += vis * T * stepLen;
    }
    return sum * lightC * phase * density;
}

void main() {
    float d0 = texture(depthtex0, uv).r;
    float d1 = texture(depthtex1, uv).r;
    vec3 col = texture(colortex0, uv).rgb;
    vec3 viewPos = toView(uv, d0);
    float dist = length(viewPos);
    vec3 V = normalize(viewPos);
    vec3 worldDir = normalize(mat3(gbufferModelViewInverse) * V);
    vec3 feetPos = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;

    vec3 sunDirW = vec3(0.0, 1.0, 0.0);
    vec3 lDirW = vec3(0.0, 1.0, 0.0);
    vec3 lightC = vec3(0.0);
    vec3 skyA = vec3(0.1);
#ifdef DIM_OVERWORLD
    sunDirW = normalize(mat3(gbufferModelViewInverse) * sunPosition);
    lDirW   = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
    lightC  = getLightColor(sunDirW);
    skyA    = getSkyAmbient(sunDirW);
#endif
#ifdef DIM_END
    lDirW  = bhDir();
    lightC = endLightColor();
    skyA   = vec3(0.20, 0.22, 0.27);
#endif
    float noise   = ign(gl_FragCoord.xy);
    bool eyeWater = (isEyeInWater == 1);
    bool isSky    = d0 >= 1.0;
    vec4 m2       = texture(colortex2, uv);
    bool isWater  = (!isSky) && m2.r > 0.5;
    float eyeSky  = float(eyeBrightnessSmooth.y) / 240.0;
    float night   = 1.0 - dayAmount(sunDirW.y);

    vec3 absC = vec3(0.30, 0.075, 0.045) * WATER_DENSITY;
    vec3 wl = (skyA * 1.2 + lightC * 0.35 * clamp(lDirW.y, 0.0, 1.0)) * mix(0.05, 1.0, eyeSky * eyeSky);
    vec3 waterScatter = vec3(0.035, 0.20, 0.25) * wl;

    // ===================== SKY (per dimension) =====================
    if (isSky) {
#if defined(DIM_NETHER)
        vec3 nf = getNetherFog();
        col = nf * (0.8 + 0.5 * (1.0 - smoothstep(-0.8, 0.1, worldDir.y)))
                 * (0.85 + 0.3 * vnoise(worldDir.xz * 3.0 + frameTimeCounter * 0.05));
#elif defined(DIM_END)
        col = getEndSky(worldDir);
#else
        col = getSky(worldDir, sunDirW) + getCelestials(worldDir, sunDirW, true, 1.0);
    #ifdef AURORA
        col += getAurora(worldDir, frameTimeCounter) * night * (1.0 - rainStrength);
    #endif
        vec4 cl = getClouds(worldDir, sunDirW, lightC, skyA);
        col = mix(col, cl.rgb, cl.a);
#endif
    }

#ifdef DIM_OVERWORLD
    // ===================== REALISTIC WATER =====================
    if (isWater) {
        vec3 N = normalize(texture(colortex1, uv).xyz * 2.0 - 1.0);
        vec3 upV = normalize(mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0));
        float cosT = clamp(abs(dot(N, V)), 0.0, 1.0);
        float skyLM = m2.g;

        vec2 uvR = uv + (N - upV).xy * 0.06 / (1.0 + dist * 0.03);
        uvR = clamp(uvR, vec2(0.002), vec2(0.998));
        float dR0 = texture(depthtex0, uvR).r;
        if (length(toView(uvR, dR0)) < dist - 0.3) uvR = uv;
        float dR1 = texture(depthtex1, uvR).r;

        vec3 under;
        float thick;
        if (dR1 >= 1.0) {
            vec3 rd = normalize(mat3(gbufferModelViewInverse) * normalize(toView(uvR, 1.0)));
            under = getSky(rd, sunDirW) + getCelestials(rd, sunDirW, true, 1.0);
            thick = 48.0;
        } else {
            under = texture(colortex0, uvR).rgb;
            thick = length(toView(uvR, dR1) - viewPos);
        }
        if (eyeWater) thick = 0.0;

        vec3 Tw = exp(-absC * thick);
        under = under * Tw + waterScatter * (1.0 - Tw);

        float F = 0.02 + 0.98 * pow(1.0 - cosT, 5.0);
        F = max(F, 0.14 * night);                       // darker water mirrors the night sky more
        if (eyeWater) F = max(F, 1.0 - smoothstep(0.55, 0.70, cosT));
        F = clamp(F, 0.0, 1.0);

        vec3 R = reflect(V, N);
        vec3 Rw = normalize(mat3(gbufferModelViewInverse) * R);
        vec3 refl;
        if (eyeWater) {
            refl = waterScatter;
        } else {
            // sky + moon + sparkling star reflections (stars boosted so they read on the water)
            vec3 skyR = getSky(Rw, sunDirW) + getCelestials(Rw, sunDirW, false, 2.2);
    #ifdef AURORA
            skyR += getAurora(Rw, frameTimeCounter) * night * (1.0 - rainStrength);
    #endif
            vec4 clr = getClouds(Rw, sunDirW, lightC, skyA);
            skyR = mix(skyR, clr.rgb, clr.a);
            refl = skyR * mix(0.04, 1.0, smoothstep(0.1, 0.9, skyLM));
        }
#ifdef WATER_SSR
        vec4 ssr = traceSSR(viewPos, R, noise);
        refl = mix(refl, ssr.rgb, ssr.a);
#endif

        vec3 Lv = normalize(shadowLightPosition);
        vec3 H = normalize(Lv - V);
        float NdH = max(dot(N, H), 0.0);
        float spec = pow(NdH, 900.0) * 14.0 + pow(NdH, 60.0) * 0.08;
        float sunVis = luma(getShadow(feetPos + vec3(0.0, 0.02, 0.0), vec3(0.0, 1.0, 0.0), 1.0, noise));
        vec3 specCol = lightC * spec * (0.15 + 0.85 * F) * sunVis * smoothstep(0.2, 0.9, skyLM) * step(0.0, dot(N, Lv));

        col = under * (1.0 - F) + refl * F + specCol;
    }
#endif

    // ===================== COLOURED LIGHT BLEED (lava, torches, glowstone...) =====================
#ifdef COLORED_LIGHT
    if (!isSky && !isWater && !eyeWater) {
        float rr = clamp(6.0 * gbufferProjection[1][1] * 0.5 / max(dist, 1.0), 0.015, 0.22);
        float asp = viewHeight / viewWidth;
        vec3 gi = vec3(0.0);
        for (int i = 0; i < 12; i++) {
            float ang = (float(i) + noise) * 2.39996;
            float r = sqrt((float(i) + 0.5) / 12.0) * rr;
            vec2 suv = clamp(uv + vec2(cos(ang) * asp, sin(ang)) * r, vec2(0.001), vec2(0.999));
            vec3 e = texture(colortex4, suv).rgb;
            if (e.r + e.g + e.b < 0.02) continue;
            float sd = texture(depthtex1, suv).r;
            float dd = distance(toView(suv, sd), viewPos);
            float w = (1.0 / (1.0 + dd * dd * 0.4)) * smoothstep(0.3, 0.9, dd) * (1.0 - smoothstep(3.0, 9.0, dd));
            gi += e * w;
        }
        gi *= (1.0 / 12.0) * 4.0 * LIGHT_BLEED;
        col += gi * (0.15 + 0.6 * min(col, vec3(1.5)));
    }
#endif

    // ===================== FOG + VOLUMETRIC LIGHT =====================
    if (eyeWater) {
        float dd = isSky ? 80.0 : dist;
        vec3 T = exp(-absC * dd);
        col = col * T + waterScatter * (1.0 - T);
#if defined(VOLUMETRIC_LIGHT) && defined(DIM_OVERWORLD)
        float vlMaxW = min(isSky ? 1000.0 : dist, SHADOW_DIST * 0.8);
        vec3 uwLight = lightC * vec3(0.35, 0.80, 1.0) * eyeSky;
        col += volumetric(worldDir, min(vlMaxW, 40.0), noise, lDirW, uwLight,
                          0.05 * VL_STRENGTH, 0.55, absC, true) * 0.6;
#endif
    } else {
#if defined(DIM_NETHER)
        if (!isSky) {
            vec3 wp = feetPos + cameraPosition;
            float n = vnoise(wp.xz * 0.05 + vec2(frameTimeCounter * 0.03, 0.0)) * 0.6
                    + vnoise(vec2(wp.x + wp.y, wp.z - wp.y) * 0.11 - frameTimeCounter * 0.02) * 0.4;
            float dens = 0.0022 * FOG_DENSITY * (0.6 + 0.8 * n);
            float T = exp(-dist * dens) * (1.0 - smoothstep(far * 0.80, far * 0.99, dist));
            col = col * T + getNetherFog() * (1.0 - T);
        }
#elif defined(DIM_END)
        if (!isSky) {
            float dens = 0.0018 * FOG_DENSITY;
            float T = exp(-dist * dens) * (1.0 - smoothstep(far * 0.70, far * 0.98, dist));
            col = col * T + endFog(worldDir) * (1.0 - T);
        }
    #ifdef VOLUMETRIC_LIGHT
        // dusty light shafts streaming from the black hole through the pillars
        float vlMaxE = min(isSky ? 1000.0 : dist, SHADOW_DIST * 0.8);
        if (!isSky) col += volumetric(worldDir, vlMaxE, noise, lDirW, lightC, 0.0009 * VL_STRENGTH, 0.75, vec3(0.0), false);
    #endif
#else
        float tw = twilightAmount(sunDirW.y);
        float dens = (0.0009 + rainStrength * 0.010 + tw * 0.0008) * FOG_DENSITY;
        if (!isSky) {
            vec3 fdir = normalize(vec3(worldDir.x, clamp(worldDir.y, 0.0, 0.12), worldDir.z));
            vec3 fogC = getSky(fdir, sunDirW);
            float T = exp(-dist * dens);
            T *= 1.0 - smoothstep(far * 0.70, far * 0.98, dist);
            col = col * T + fogC * (1.0 - T);
        }
    #ifdef VOLUMETRIC_LIGHT
        float vlMax = min(isSky ? 1000.0 : dist, SHADOW_DIST * 0.8);
        // stronger shafts at sunset / sunrise, and boosted moon shafts at night
        float vd = (0.0035 + tw * 0.0075 + rainStrength * 0.002 + night * 0.004) * VL_STRENGTH;
        col += volumetric(worldDir, vlMax, noise, lDirW, lightC, vd, 0.70, vec3(0.0), false);
    #endif
#endif
    }

#if defined(FIREFLIES) && defined(DIM_OVERWORLD)
    {
        float ff = night * (1.0 - rainStrength) * (eyeWater ? 0.0 : 1.0);
        if (ff > 0.01) {
            float mdist = isSky ? 26.0 : min(dist, 26.0);
            col += fireflies(worldDir, mdist, vec3(0.7, 1.0, 0.25) * 3.0, frameTimeCounter) * ff;
        }
    }
#endif

    gl_FragData[0] = vec4(col, 1.0);
}
