#version 330 compatibility
#define DIM_NETHER
#define PASS_WEATHER
#include "/lib/lit_vert.glsl"
