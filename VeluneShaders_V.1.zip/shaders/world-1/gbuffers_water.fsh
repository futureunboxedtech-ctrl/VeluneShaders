#version 330 compatibility
#define DIM_NETHER
/* DRAWBUFFERS:012 */
#define PASS_WATER
#define USE_BLOCK_ID
#include "/lib/lit_frag.glsl"
