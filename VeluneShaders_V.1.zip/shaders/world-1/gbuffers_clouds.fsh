#version 330 compatibility
#define DIM_NETHER
#define PASS_CLOUDS
#include "/lib/lit_frag.glsl"
