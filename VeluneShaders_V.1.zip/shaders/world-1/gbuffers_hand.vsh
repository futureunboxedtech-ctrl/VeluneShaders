#version 330 compatibility
#define DIM_NETHER
#define PASS_HAND
#include "/lib/lit_vert.glsl"
