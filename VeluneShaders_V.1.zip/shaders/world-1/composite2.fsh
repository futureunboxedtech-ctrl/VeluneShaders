#version 330 compatibility
#define DIM_NETHER
/* DRAWBUFFERS:3 */
#include "/lib/common.glsl"
#include "/lib/uniforms.glsl"
in vec2 uv;
// vertical blur
void main() {
    vec2 px = 1.0 / vec2(viewWidth, viewHeight);
    vec3 sum = vec3(0.0);
    float tot = 0.0;
    for (int i = -7; i <= 7; i++) {
        float w = exp(-float(i * i) / 24.5);
        sum += texture(colortex3, uv + vec2(0.0, float(i) * 2.0 * px.y)).rgb * w;
        tot += w;
    }
    gl_FragData[0] = vec4(sum / tot, 1.0);
}
