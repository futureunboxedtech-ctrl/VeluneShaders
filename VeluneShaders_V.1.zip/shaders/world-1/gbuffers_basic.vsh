#version 330 compatibility
#define DIM_NETHER
out vec4 glcolor;
void main() { glcolor = gl_Color; gl_Position = ftransform(); }
