#version 330 compatibility
#define DIM_NETHER
#define PASS_PARTICLE
#include "/lib/lit_frag.glsl"
